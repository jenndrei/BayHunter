RF Mini
=======

A simple and fast receiver function forward routine in a small, self
contained package usable from Python.

Author: Joachim Saul, GFZ Potsdam, saul@gfz-potsdam.de
