#!/usr/bin/env python
# -*- coding: utf-8 -*-

# The earth model is now specified as several numpy arrays:
#
# z  depths of the top of each layer
# vp, vs, rho, qp, qs
#
# All of the above arrays must have the same length, which is not
# checked! This length is the number of layers. There are no
# gradient layers.

import numpy, rfmini

# constant-velocity crust on top of homogeneous upper mantle
z  = numpy.array( [ 0., 30] )
vp = numpy.array( [ 6.5, 8.0 ] )
vs = vp/(3**0.5)
rh = numpy.array( [ 2.7, 3.3 ] )
qp = numpy.array( [ 500., 500 ] )
qs = numpy.array( [ 225., 225 ] )

# slowness in s/deg
angular_slowness = 6.4

p = angular_slowness/111.195

# gauss parameter
a = 4.

# number of samples
nsamp = 1024

# sampling frequency
fsamp = 10.

# lead time in seconds
tshift = 10.

# near-surface S velocity and Poisson's ratio for P/SV decomposition
nsv, sigma = 3.5, 0.25

# incident wave type, either "P", "SV" or "SH"
wave = "P"

fp,fsv,rf = rfmini.synrf(z,vp,vs,rh,qp,qs,p,a,nsamp,fsamp,tshift,nsv,sigma,wave)

f = open("rf.txt","w")

# use rf, e.g. print it to a text file

for i,x in enumerate(rf):
    f.write("%.2f %.6f\n" % (i/fsamp-tshift, x))

# As of 2018-12-21, 1000 computations took 1.6 seconds.
