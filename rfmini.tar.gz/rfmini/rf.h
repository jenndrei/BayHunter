/******************************************************************
 *                                                                *
 *   Copyright by Joachim Saul <saul@gfz-potsdam.de>              *
 *                                                                *
 ******************************************************************/

# ifndef _INVRF_H_
# define _INVRF_H_

# include <string.h>
# include "defaults.h"


// parameters for receiver function computation
struct RfnParam
{
	double	p,       // horizontal slowness
		fsamp,   // sampling frequency
		water,   // waterlevel
		a,       // gauss parameter
		tshift,  // time shift  
		vptop, vstop; // rotation velocities
	int	nsamp;   // number of samples

	RfnParam () {
		// initialize with default values
		p      = PDEF_P;
		fsamp  = PDEF_FSAMP;
		water  = PDEF_WATER;
		a      = PDEF_GAUSS;
		tshift = PDEF_TSHIFT;
		vstop  = vptop = 0.0;
		nsamp  = PDEF_NSAMP;
	}
};

# endif
